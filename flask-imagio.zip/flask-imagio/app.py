from flask import Flask, request, jsonify, send_from_directory, render_template
import imageio
import os
import uuid
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Create directories for image uploads and videos
os.makedirs('images', exist_ok=True)
os.makedirs('static', exist_ok=True)

# Set allowed image extensions
ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png'}

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def index():
    return render_template('index.html')  # This renders the index.html file

@app.route('/upload', methods=['POST'])
def upload_images():
    # Check if images were uploaded
    if 'images' not in request.files:
        return jsonify({"error": "No images provided"}), 400

    files = request.files.getlist('images')
    images = []

    for file in files:
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join('images', filename)
            file.save(file_path)
            images.append(file_path)
        else:
            return jsonify({"error": "Invalid file format"}), 400

    # Convert images to video
    video_path = convert_images_to_video(images)

    return jsonify({"video_url": video_path}), 200

def convert_images_to_video(image_paths):
    # Generate unique video name
    video_filename = str(uuid.uuid4()) + '.mp4'
    video_path = os.path.join('static', video_filename)

    # Set FPS (Frames Per Second) for video
    fps = 30

    # Create video writer object
    writer = imageio.get_writer(video_path, fps=fps)

    # Loop through images and add them to the video
    for image_path in image_paths:
        image = imageio.imread(image_path)
        writer.append_data(image)

    writer.close()
    return video_path

@app.route('/videos/<filename>')
def download_video(filename):
    return send_from_directory('static', filename)

if __name__ == '__main__':
    app.run(debug=True)